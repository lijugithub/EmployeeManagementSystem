package com.work.employee.service;

import com.work.employee.entity.Department;

import java.util.List;

public interface DepartmentService {
    List<Department> getAllDepartments();
}
